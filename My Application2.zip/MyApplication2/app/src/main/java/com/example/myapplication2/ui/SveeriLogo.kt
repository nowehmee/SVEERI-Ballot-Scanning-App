package com.example.myapplication2.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun SveeriLogo(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFF000B30)
) {
    Canvas(modifier = modifier) {
        val strokeWidth = 4.dp.toPx()
        val mainCircleRadius = size.width * 0.35f
        
        val centerX = size.width / 2f - 6.dp.toPx()
        val centerY = size.height / 2f - 12.dp.toPx()

        drawCircle(
            color = color,
            radius = mainCircleRadius,
            center = Offset(centerX, centerY),
            style = Stroke(width = strokeWidth)
        )

        val chainX = centerX + mainCircleRadius + 3.dp.toPx()
        val firstDotY = centerY + 4.dp.toPx()
        val dotRadius = 2.2.dp.toPx()
        val dotSpacing = 7.dp.toPx()

        for (i in 0 until 4) {
            drawCircle(
                color = color,
                radius = dotRadius,
                center = Offset(chainX, firstDotY + i * dotSpacing),
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        val lockWidth = 12.dp.toPx()
        val lockHeight = 10.dp.toPx()
        val lockX = chainX - lockWidth / 2f
        val lockY = firstDotY + 3 * dotSpacing + 8.dp.toPx()

        drawRect(
            color = color,
            topLeft = Offset(lockX, lockY),
            size = Size(lockWidth, lockHeight)
        )

        drawRoundRect(
            color = color,
            topLeft = Offset(lockX + 2.5.dp.toPx(), lockY - 5.dp.toPx()),
            size = Size(lockWidth - 5.dp.toPx(), 7.dp.toPx()),
            cornerRadius = CornerRadius(2.5.dp.toPx(), 2.5.dp.toPx()),
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
