package com.example.myapplication2.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication2.R
import com.example.myapplication2.ui.theme.MyApplication2Theme
import kotlinx.coroutines.delay

@Composable
fun DashboardScreen(modifier: Modifier = Modifier) {
    var showSecondImage by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1500) // Reduced delay for faster transition cycle
            showSecondImage = !showSecondImage
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Crossfade(
            targetState = showSecondImage,
            animationSpec = tween(durationMillis = 600), // Faster crossfade animation
            label = "ImageTransition"
        ) { isSecond ->
            val imageRes = if (isSecond) R.drawable.sveeri_2 else R.drawable.sveeri_1
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DashboardScreenPreview() {
    MyApplication2Theme {
        DashboardScreen()
    }
}
